<?php
echo json_encode(array('success' => true));