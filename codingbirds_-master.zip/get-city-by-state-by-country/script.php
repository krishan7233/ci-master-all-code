<?php
if (isset($_POST['submit'])) {
    echo $_POST['country'];echo '<br/>';
    echo $_POST['state'];echo '<br/>';
    echo $_POST['city'];echo '<br/>';

}
